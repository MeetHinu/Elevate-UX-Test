// Regenerates web-ready WebP images in public/images from the untouched originals
// in images-original/. Keeps the same sharpen + contrast treatment as
// sharpen-images.js, but resizes (long side <= 1800px) and encodes as WebP.
//
//   npm run optimize-images
import { readdir, mkdir, stat, rm } from "node:fs/promises";
import path from "node:path";
import sharp from "sharp";

const ORIGINALS = path.resolve("images-original");
const OUTPUT = path.resolve("public/images");
const CATEGORIES = ["bathroom", "kitchen", "laundry", "living", "team"];
const MAX_SIDE = 1800;
const QUALITY = 80;

let totalBefore = 0;
let totalAfter = 0;

for (const category of CATEGORIES) {
  const srcDir = path.join(ORIGINALS, category);
  const outDir = path.join(OUTPUT, category);
  await mkdir(outDir, { recursive: true });
  const files = (await readdir(srcDir)).filter((f) => /\.jpe?g$/i.test(f));

  for (const file of files) {
    const srcPath = path.join(srcDir, file);
    const base = file.replace(/\.jpe?g$/i, "");
    const outPath = path.join(outDir, `${base}.webp`);

    await sharp(srcPath)
      .rotate() // honour EXIF orientation
      .resize({ width: MAX_SIDE, height: MAX_SIDE, fit: "inside", withoutEnlargement: true })
      .sharpen({ sigma: 1.0, m1: 1.0, m2: 2.0 })
      .linear(1.05, -8)
      .webp({ quality: QUALITY, effort: 5 })
      .toFile(outPath);

    // Remove the old heavy JPEG from the deployed folder (original stays in images-original/)
    await rm(path.join(outDir, file), { force: true });

    const before = (await stat(srcPath)).size;
    const after = (await stat(outPath)).size;
    totalBefore += before;
    totalAfter += after;
    console.log(`${category}/${base}: ${(before / 1e6).toFixed(2)} MB -> ${(after / 1e6).toFixed(2)} MB`);
  }
}
console.log(`\nOriginals ${(totalBefore / 1e6).toFixed(1)} MB -> deployed ${(totalAfter / 1e6).toFixed(1)} MB`);
