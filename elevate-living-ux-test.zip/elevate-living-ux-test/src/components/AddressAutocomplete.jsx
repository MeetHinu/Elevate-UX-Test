import { useEffect, useRef, useState } from "react";
import { searchAddresses } from "../lib/addressSearch.js";

const MIN_QUERY_LENGTH = 4;
const DEBOUNCE_MS = 600;

// ARIA 1.2 combobox with list autocomplete: arrow keys move through options,
// Enter selects, Escape closes. Focus stays in the input the whole time.
export default function AddressAutocomplete({ id, name, value, onChange, disabled, required }) {
  const [suggestions, setSuggestions] = useState([]);
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const containerRef = useRef(null);
  const debounceRef = useRef(null);
  const abortRef = useRef(null);

  const listboxId = `${id}-listbox`;
  const optionId = (i) => `${id}-option-${i}`;

  useEffect(() => {
    function handleClickOutside(event) {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setOpen(false);
        setActiveIndex(-1);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    return () => {
      clearTimeout(debounceRef.current);
      if (abortRef.current) abortRef.current.abort();
    };
  }, []);

  const handleInputChange = (event) => {
    onChange(event);
    const query = event.target.value;

    clearTimeout(debounceRef.current);
    if (abortRef.current) abortRef.current.abort();
    setActiveIndex(-1);

    if (query.trim().length < MIN_QUERY_LENGTH) {
      setSuggestions([]);
      setOpen(false);
      return;
    }

    debounceRef.current = setTimeout(async () => {
      const controller = new AbortController();
      abortRef.current = controller;
      try {
        const results = await searchAddresses(query, { signal: controller.signal });
        setSuggestions(results);
        setOpen(results.length > 0);
      } catch (err) {
        if (err.name !== "AbortError") {
          setSuggestions([]);
          setOpen(false);
        }
      }
    }, DEBOUNCE_MS);
  };

  const handleSelect = (label) => {
    onChange({ target: { name, value: label } });
    setSuggestions([]);
    setOpen(false);
    setActiveIndex(-1);
  };

  const handleKeyDown = (event) => {
    if (event.key === "Escape" && open) {
      event.preventDefault();
      setOpen(false);
      setActiveIndex(-1);
      return;
    }
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      if (suggestions.length === 0) return;
      event.preventDefault();
      if (!open) {
        setOpen(true);
        setActiveIndex(event.key === "ArrowDown" ? 0 : suggestions.length - 1);
        return;
      }
      const delta = event.key === "ArrowDown" ? 1 : -1;
      setActiveIndex((i) => (i + delta + suggestions.length) % suggestions.length);
      return;
    }
    if (event.key === "Enter" && open && activeIndex >= 0) {
      event.preventDefault(); // choose the suggestion instead of submitting the form
      handleSelect(suggestions[activeIndex].label);
    }
  };

  return (
    <div ref={containerRef} style={{ position: "relative" }}>
      <input
        type="text"
        id={id}
        name={name}
        value={value}
        onChange={handleInputChange}
        onKeyDown={handleKeyDown}
        onFocus={() => setOpen(suggestions.length > 0)}
        disabled={disabled}
        required={required}
        role="combobox"
        aria-expanded={open}
        aria-autocomplete="list"
        aria-controls={listboxId}
        aria-activedescendant={open && activeIndex >= 0 ? optionId(activeIndex) : undefined}
        autoComplete="street-address"
      />
      <span className="visually-hidden" aria-live="polite">
        {open ? `${suggestions.length} address suggestions available. Use up and down arrows to review.` : ""}
      </span>
      {open && (
        <ul id={listboxId} role="listbox" className="address-suggestions">
          {suggestions.map((item, i) => (
            <li
              key={item.id}
              id={optionId(i)}
              role="option"
              aria-selected={i === activeIndex}
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => handleSelect(item.label)}
              onMouseEnter={() => setActiveIndex(i)}
              style={{ cursor: "pointer" }}
            >
              <span className="address-option">{item.label}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
