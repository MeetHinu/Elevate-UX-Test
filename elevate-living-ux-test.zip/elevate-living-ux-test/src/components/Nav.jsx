import { useEffect, useState } from "react";
import { Link, NavLink } from "react-router-dom";

export default function Nav() {
  const [open, setOpen] = useState(false);
  const linkClass = ({ isActive }) => (isActive ? "active" : "");
  const close = () => setOpen(false);

  // Escape closes the mobile menu
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <nav className="site-nav" aria-label="Main">
      <div className="wrap">
        <Link to="/" className="logo-mark" onClick={close}>
          <img src="/images/logo/logo.png" alt="Elevate Living Interior Design Studio" />
        </Link>
        <div id="site-menu" className={`nav-links${open ? " open" : ""}`}>
          <NavLink to="/" className={linkClass} onClick={close} end>Home</NavLink>
          <NavLink to="/services" className={linkClass} onClick={close}>Services</NavLink>
          <NavLink to="/portfolio" className={linkClass} onClick={close}>Portfolio</NavLink>
          <NavLink to="/about" className={linkClass} onClick={close}>About</NavLink>
          <NavLink to="/contact" className={linkClass} onClick={close}>Contact</NavLink>
          <Link to="/contact" className="nav-cta" onClick={close}>Book a Consultation</Link>
        </div>
        <button
          type="button"
          className="nav-toggle"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          aria-controls="site-menu"
          onClick={() => setOpen((v) => !v)}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
            {open ? (
              <path d="M6 6l12 12M18 6L6 18" />
            ) : (
              <path d="M4 7h16M4 12h16M4 17h16" />
            )}
          </svg>
        </button>
      </div>
    </nav>
  );
}
