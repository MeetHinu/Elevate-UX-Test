// Hero photos are decorative (the h1 + description carry the meaning), so alt is empty.
export default function PageHero({ image, eyebrow, title, description }) {
  return (
    <header className="page-hero">
      <img src={image} alt="" decoding="async" />
      <div className="page-hero-content">
        {eyebrow && <p className="eyebrow">{eyebrow}</p>}
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
    </header>
  );
}
