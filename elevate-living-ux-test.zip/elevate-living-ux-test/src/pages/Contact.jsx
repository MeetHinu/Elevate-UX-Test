import { useRef, useState } from "react";
import PageHero from "../components/PageHero.jsx";
import AddressAutocomplete from "../components/AddressAutocomplete.jsx";
import { encodeForm } from "../lib/encodeForm.js";
import { isValidEmail, isValidPhone } from "../lib/validation.js";
import { usePageMeta } from "../lib/usePageMeta.js";

const initialState = {
  name: "",
  email: "",
  phone: "",
  address: "",
  project: "",
  timeline: "",
  hearAbout: "",
  message: "",
  "bot-field": "",
};

export default function Contact() {
  usePageMeta("Book a Consultation", "Tell us about your kitchen, bathroom, laundry or living space and book a design consultation with Elevate Living in Melbourne.");
  const [status, setStatus] = useState("idle");
  const [form, setForm] = useState(initialState);
  const [errors, setErrors] = useState({});
  const successRef = useRef(null);

  const busy = status === "sending";

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    const nextErrors = {};
    if (!form.name.trim()) {
      nextErrors.name = "Please enter your name.";
    }
    if (!isValidEmail(form.email)) {
      nextErrors.email = "Please enter a valid email address, e.g. name@example.com.";
    }
    if (!form.phone.trim()) {
      nextErrors.phone = "Please enter your phone number.";
    } else if (!isValidPhone(form.phone)) {
      nextErrors.phone = "Please enter a valid phone number, e.g. 0412 345 678.";
    }
    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      // Move focus to the first invalid field so keyboard and screen-reader users land on it
      const firstInvalid = ["name", "email", "phone"].find((key) => nextErrors[key]);
      if (firstInvalid) document.getElementById(firstInvalid)?.focus();
      return;
    }
    setErrors({});

    setStatus("sending");
    fetch("/", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: encodeForm({ "form-name": "consultation-request", ...form }),
    })
      .then((response) => {
        if (!response.ok) throw new Error(`Form submission failed: ${response.status}`);
        setStatus("sent");
        // Let the confirmation panel mount, then move focus to it
        setTimeout(() => successRef.current?.focus(), 0);
      })
      .catch(() => setStatus("error"));
  };

  const resetForm = () => {
    setForm(initialState);
    setErrors({});
    setStatus("idle");
  };

  const hasErrors = Object.values(errors).some(Boolean);

  return (
    <>
      <PageHero
        image="/images/kitchen/kitchen-8.webp"
        title="Tell us about your space."
        description="Fill in a few details and we'll get back to you within two business days to arrange a consultation."
      />

      <section className="section-cream">
        <div className="wrap grid-2">
          <div>
            {status === "sent" ? (
              <div className="form-success" role="status" tabIndex={-1} ref={successRef}>
                <h2>Thank you, {form.name.trim().split(" ")[0]}.</h2>
                <p>
                  Your consultation request has been sent. We'll be in touch within two business days at{" "}
                  {form.email.trim()}.
                </p>
                <button type="button" className="btn btn-outline-dark" onClick={resetForm}>
                  Send another request
                </button>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                noValidate
                name="consultation-request"
                data-netlify="true"
                netlify-honeypot="bot-field"
              >
                <input type="hidden" name="form-name" value="consultation-request" />
                <p style={{ display: "none" }}>
                  <label>
                    Don't fill this out if you're human:{" "}
                    <input name="bot-field" value={form["bot-field"]} onChange={handleChange} tabIndex={-1} />
                  </label>
                </p>

                <p style={{ fontSize: 13, color: "var(--text-ink-dim)" }}>
                  Fields marked <span className="req" aria-hidden="true">*</span>
                  <span className="visually-hidden">with an asterisk</span> are required.
                </p>

                <div className="form-row">
                  <div>
                    <label htmlFor="name">
                      Full Name <span className="req" aria-hidden="true">*</span>
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      disabled={busy}
                      autoComplete="name"
                      aria-invalid={!!errors.name}
                      aria-describedby={errors.name ? "name-error" : undefined}
                      required
                    />
                    {errors.name && (
                      <p id="name-error" role="alert" className="field-error">{errors.name}</p>
                    )}
                  </div>
                  <div>
                    <label htmlFor="email">
                      Email <span className="req" aria-hidden="true">*</span>
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={form.email}
                      onChange={handleChange}
                      disabled={busy}
                      autoComplete="email"
                      aria-invalid={!!errors.email}
                      aria-describedby={errors.email ? "email-error" : undefined}
                      required
                    />
                    {errors.email && (
                      <p id="email-error" role="alert" className="field-error">{errors.email}</p>
                    )}
                  </div>
                </div>

                <div className="form-row">
                  <div>
                    <label htmlFor="phone">
                      Phone <span className="req" aria-hidden="true">*</span>
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={form.phone}
                      onChange={handleChange}
                      disabled={busy}
                      autoComplete="tel"
                      placeholder="0412 345 678"
                      aria-invalid={!!errors.phone}
                      aria-describedby={errors.phone ? "phone-error" : undefined}
                      required
                    />
                    {errors.phone && (
                      <p id="phone-error" role="alert" className="field-error">{errors.phone}</p>
                    )}
                  </div>
                  <div>
                    <label htmlFor="project">Project Type</label>
                    <select id="project" name="project" value={form.project} onChange={handleChange} disabled={busy}>
                      <option value="">Select…</option>
                      <option>Kitchen</option>
                      <option>Bathroom</option>
                      <option>Laundry</option>
                      <option>Living Space</option>
                      <option>Whole Home</option>
                      <option>Not Sure Yet</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="address">Project Address</label>
                  <AddressAutocomplete
                    id="address"
                    name="address"
                    value={form.address}
                    onChange={handleChange}
                    disabled={busy}
                  />
                </div>

                <div className="form-row">
                  <div>
                    <label htmlFor="timeline">When are you hoping to begin?</label>
                    <select id="timeline" name="timeline" value={form.timeline} onChange={handleChange} disabled={busy}>
                      <option value="">Select…</option>
                      <option>As soon as possible</option>
                      <option>Within 3 months</option>
                      <option>3–6 months</option>
                      <option>6–12 months</option>
                      <option>Just researching, no timeline yet</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="hearAbout">How did you hear about us?</label>
                    <select id="hearAbout" name="hearAbout" value={form.hearAbout} onChange={handleChange} disabled={busy}>
                      <option value="">Select…</option>
                      <option>Instagram</option>
                      <option>Google Search</option>
                      <option>Referral from a friend or family member</option>
                      <option>Referral from a builder or trade</option>
                      <option>Other</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="message">Tell us about your space</label>
                  <textarea
                    id="message"
                    name="message"
                    value={form.message}
                    onChange={handleChange}
                    disabled={busy}
                    placeholder="Room size, current condition, timeline, anything else that helps us prepare."
                  />
                </div>

                <div>
                  {hasErrors && (
                    <p className="form-error-summary" role="alert" style={{ marginBottom: 16 }}>
                      Please check the highlighted fields and try again.
                    </p>
                  )}
                  <button type="submit" className="btn btn-primary" disabled={busy}>
                    {busy ? "Sending…" : "Request Consultation"}
                  </button>
                  <p aria-live="polite" className="visually-hidden">
                    {busy ? "Sending your request…" : ""}
                  </p>
                  {status === "error" && (
                    <p role="alert" className="field-error" style={{ marginTop: 12 }}>
                      Something went wrong. Please try again, or email us directly at{" "}
                      <a href="mailto:info@elevatelivingstudio.com.au" style={{ textDecoration: "underline" }}>info@elevatelivingstudio.com.au</a>.
                    </p>
                  )}
                </div>
              </form>
            )}
          </div>
          <div className="photo-card" style={{ aspectRatio: "auto", height: "100%", minHeight: 340 }}>
            <img src="/images/living/living-6.webp" alt="" loading="lazy" decoding="async" />
          </div>
        </div>
      </section>

      <section className="section-alt">
        <div className="wrap grid-2">
          <div>
            <p className="eyebrow">Reach Out</p>
            <h3 style={{ fontSize: 20, marginTop: 10 }}>Get in Touch</h3>
            <p style={{ marginTop: 10, color: "var(--text-ink-dim)", fontSize: 14 }}>
              <a href="mailto:info@elevatelivingstudio.com.au">info@elevatelivingstudio.com.au</a>
              <br />
              <a href="tel:+61402601808">0402 601 808</a>
            </p>
          </div>
          <div>
            <p className="eyebrow">Hours</p>
            <h3 style={{ fontSize: 20, marginTop: 10 }}>Studio Hours</h3>
            <p style={{ marginTop: 10, color: "var(--text-ink-dim)", fontSize: 14 }}>
              Monday – Friday: 9am – 5:30pm<br />Saturday: By appointment
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
