export const services = [
  {
    title: "Kitchen Design",
    img: "/images/kitchen/kitchen-2.webp",
    text: "Layout, joinery, benchtops and appliances planned as one continuous surface.",
    items: ["Layout & Millwork", "Benchtops & Splashbacks", "Lighting Design", "Appliance Integration"],
  },
  {
    title: "Bathroom Design",
    img: "/images/bathroom/bathroom-3.webp",
    text: "Tiling, fittings and fixtures detailed for daily use and long wear.",
    items: ["Tiling & Waterproofing", "Fixtures & Fittings", "Vanity & Storage", "Wet-Room Detailing"],
  },
  {
    title: "Laundry & Utility",
    img: "/images/laundry/laundry-3.webp",
    text: "Hardworking spaces designed to feel as considered as the rest of the home.",
    items: ["Cabinetry & Storage", "Benchtops & Sinks", "Appliance Planning", "Drying & Folding Zones"],
  },
  {
    title: "Living Spaces",
    img: "/images/living/living-1.webp",
    text: "Living and dining areas planned around how you actually live day to day.",
    items: ["Furniture Layout", "Lighting Plans", "Material & Colour Palettes", "Styling & Sourcing"],
  },
];
